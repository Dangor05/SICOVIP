/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var manita = false;

$(function(){
   
   $(window).on("scroll",function(){
       var sT = window.pageYOffset;
       $("#debug").html("Offset Top: "+sT+" px");
       
       if(sT >= 1100){
           holaManita();
       }
       
       if(sT < 1100){
           chaoManita();
       }
   });

   $("#login").click(function(){
      $(".floatingWindow").slideToggle();
   });
   
});

function holaManita(){
    if(!manita){
        $("#manita").animate({
            marginLeft: "320px"
        },800,function(){
            manita = true;
        });
        
    }
}

function chaoManita(){
    if(manita){
        $("#manita").animate({
            marginLeft: "-150px"
        },800,function(){
            manita = false;
        });
        
    }
}