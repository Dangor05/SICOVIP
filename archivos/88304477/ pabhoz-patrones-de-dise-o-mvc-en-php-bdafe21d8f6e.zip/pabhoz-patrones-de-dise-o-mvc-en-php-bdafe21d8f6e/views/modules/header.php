<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title><?php print($this->title); ?></title>
        <link rel="stylesheet" href="<?php print(URL); ?>public/styles/style.css">
        <script src="<?php print(URL); ?>public/plugins/JQuery/jQuery-2.1.4.min.js"></script>
        <script src="<?php print(URL); ?>public/plugins/ParallaxJS/parallax.js-1.4.2/parallax.min.js"></script>
    </head>